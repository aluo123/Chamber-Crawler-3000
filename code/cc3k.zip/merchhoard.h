#ifndef __MERCHHOARD_H__
#define __MERCHHOARD_H__

#include "gold.h"

class MerchHoard:public Gold{
public:
	MerchHoard():Gold(4){}
	~MerchHoard(){}

};

#endif
