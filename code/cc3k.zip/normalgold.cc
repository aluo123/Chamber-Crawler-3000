#include "normalgold.h"

NormalGold::NormalGold():Gold(2){}
NormalGold::~NormalGold(){}
