#ifndef __NORMALGOLD_H__
#define __NORMALGOLD_H__

#include "gold.h"

class NormalGold:public Gold{
public:
	NormalGold();
	~NormalGold();

};

#endif

