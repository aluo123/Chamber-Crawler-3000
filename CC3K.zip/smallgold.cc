#include "smallgold.h"

SmallGold::SmallGold():Gold(1){}

SmallGold::~SmallGold(){}
