#ifndef __DROW_H__
#define __DROW_H__

#include "player.h"

class Drow:public Player{
	void useItem(Item *item);
public:
	Drow();
	~Drow();
	std::string Type();
};

#endif
