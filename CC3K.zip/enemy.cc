#ifndef __ENEMY_H__
#define __ ENEMY_H__

#include "enemy.h"

#include <string>
#include <cstdlib>
#include <ctime>
#include "player.h"

using namespace std;

Enemy::Enemy(int hp,int atk,int def):Character(hp,atk,def),item(NULL){
}

Enemy::~Enemy(){
	delete item;
}

void Enemy::die(Character *killer){
	dropItem(killer);
    if(killer->raceType() == "goblin"){
		Player *p = dynamic_cast<Player*>(killer);
		p->addGold(5);
	}
	delete this;
}

void Enemy::dropItem(Character *player){
	srand(time(NULL));
	int random = rand() % 2;
	Player *p = dynamic_cast<Player*>(player);
	if(random){
		item = new SmallGold();
	}else{
		item = new NormalGold();
	}
	item->drop(p);
}

bool checkRadius(){
/*	for(int i=0;i<8;i++){
		Cell *neighbour = currentCell->getNeighbour(radius[i]);
		if(neighbour!=NULL){
			Character *c = neighbour->getCharacter();
			if(c){
				if(c->characType()=="player"){
					attack(radius[i]);
					return true;
				}
			}
		}
	}
*/
	return false;
}

string characType(){
	return "enemy";
}

#endif

