#ifndef __SMALLGOLD_H__
#define __SMALLGOLD_H__

#include "gold.h"

class SmallGold:public Gold{
public:
	SmallGold();
	~SmallGold();

};

#endif

