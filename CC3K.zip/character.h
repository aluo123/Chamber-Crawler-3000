#ifndef __CHARACTER_H__
#define __CHARACTER_H__
#include <string>

//An abstract class Character to provide an interface for 
//player and enemy races

class Cell;

class Character{
protected:
	//status of the character
	int HP;
	int ATK;
	int DEF;
	
	//the position of the player on the board 
	//****changes when austin finishes tile
	int row,col;

	//tile that the character is currently standing on
	Cell *currentCell;
	
	//character default ctor
	Character(int hp=0,int atk=0, int def=0);
		
	//instructions for dying
	virtual void die(Character *killer)=0;
	
	static const std::string radius[8];
	
public:
	// makes Character abstract
	virtual ~Character()=0;
	//updates player stats
	void setHP(int hp);
	void setDEF(int def);
	void setATK(int atk);
	int getHP();
	int getDEF();
	int getATK();
	

	//sets the coordinates for the character
	void setCoord(Cell *cell);
	
	//attacks the target
	virtual void attack(std::string &dir);
	
	//moves the character around
	virtual void move(const std::string &dir);
	
	//called by the enemy to hit the this character
	virtual void getHit(int dmg, Character *attacker);
	
	virtual std::string raceType()=0;
	
	virtual std::string characType()=0;
};

#endif

