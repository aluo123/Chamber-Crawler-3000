#include "game.h"
#include "floor.h"
/*
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
*/
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

Game::Game( GameNotification *notification ): notification(notification) {
	for ( int i = 0; i < 5; i++ ){
		floors[i] = new Floor(this);
	}
	floorNum = 0;
	notify( "floor", 1 );
}

Game::~Game(){
	clearGame();
	for ( int i = 0; i < 5; i++ ) {
		delete floors[i];
	}
}

void Game::init(){
	for ( int i = 0; i < 5; i++ ) {
		floors[i]->init();
	}
	currentFloor = floors[0];
	currentFloor->notify();
}

/*
Character *Game::makeCharacter( char cell ) {
	Character * newChar;
	if ( cell == '0' ) {
		newChar = new RH();
	}
	else if ( cell == '1' ) {
		newChar = new BA();
	}
	else if ( cell == '2' ) {
		newChar = new BD();
	}
	else if ( cell == '3' ) {
		newChar = new PH();
	}
	else if ( cell == '4' ) {
		newChar = new WA();
	}
	else if ( cell == '5' ) {
		newChar = new WD();
	}
	else if ( cell == '6' ) {
		newChar = new NormalGold();
	}
	else if ( cell == '7' ) {
		newChar = new SmallGold();
	}
	else if ( cell == '8' ) {
		newChar = new MerchHoard();
	}
	else if ( cell == '9' ) {
		newChar = new DragHoard();
	}
}
*/

void Game::init( ifstream fs ) {
	string temp;
	for ( int i = 0; i < 5; i++ ) {
		for ( int j = 0; j < 25; j++ ) {
			getline(fs, temp);
			istringstream ss(temp);
			for ( int k = 0; k < 79; k++ ) {
				char cell;
				ss >> cell;
			}
		}
	}
}

void Game::clearGame(){
	delete player;
}

void Game::createPlayer( string race ) {
	if ( race == "s" ) {
		//player = new Shade();
		setRace("Shade");
	}
	else if ( race == "d" ) {
		//player = new Drow();
		setRace("Drow");
	}
	else if ( race == "v" ) {
		//player = new Vampire();
		setRace("Vampire");
	}
	else if ( race == "t" ) {
		//player = new Troll();
		setRace("Troll");
	}
	else if ( race == "g" ) {
		//player = new Goblin();
		setRace("Goblin");
	}
}

string convertDir( string dir ) {
	if ( dir == "no" ) return "North";
	if ( dir == "ne" ) return "North-East";
	if ( dir == "nw" ) return "North-West";
	if ( dir == "ea" ) return "East";
	if ( dir == "we" ) return "West";
	if ( dir == "so" ) return "South";
	if ( dir == "se" ) return "South-East";
	if ( dir == "sw" ) return "South-West";
}

void Game::attack( string dir ) {
	string attackAction = "Attack " + dir;
	notify(attackAction);
	//player->attack(dir);
}

void Game::move( string dir ) {
	string moveAction = "PC moves " + convertDir(dir);
	//player->move(dir);
}

void Game::use( string dir ) {
	#ifdef DEBUG
	cout << "Use " << dir << endl;
	#endif
	//player->useItem(dir);
}

void Game::setRace( string race ) {
	notification->setRace(race);
}

void Game::notify( int r, int c, char ch ) const {
	notification->notify(r,c,ch);
}

void Game::notify( string action ) const {
	notification->notify(action);
}

void Game::notify( string stat, int newStat ) const {
	notification->notify(stat,newStat);
}

void Game::advanceFloor(){
	floorNum++;
	currentFloor = floors[floorNum];
	currentFloor->notify();
	notify( "floor", floorNum+1 );
}
