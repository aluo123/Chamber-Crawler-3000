#include "orc.h"
#include <cmath>

Orc::Orc(Player *player):Enemy(player,180,30,25){}
Orc::~Orc(){}

void Orc::attack(Character *target){
	if(target->Type() == "goblin"){
		float fTDef = (float)target->getDEF();
		float fATK = (float)ATK;
		float fdmg = ceil((1.5*(100/(100+fTDef))*fATK));
		int dmg = (int)fdmg;
		target->getHit(dmg);
	}else{
		Enemy::attack(target);
	}
}