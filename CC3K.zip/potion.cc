#include "potion.h"
#include <string>

using namespace std;

Potion::Potion(){}

//returns the player without power ups to the tile
// and deletes the power upped player
Potion::~Potion(){
	player->setCurrentPlayer(player);
	delete this;
}

