#include "player.h"
#include <string>
#include <cstdlib>
#include "cell.h"
#include "gold.h"
#include "potion.h"
#include "draghoard.h"

using namespace std;

Player::Player(int hp, int atk, int def):Character(hp,atk,def),goldAmount(0){}

Player::~Player(){}

void Player::setCurrentPlayer(Player *player){
	currentCell->setPlayer(player);
}

void Player::addGold(int amount){
	goldAmount += amount;
}

void Player::move(string &dir){
	Cell *nextCell = currentCell->getNeighbour(dir);
	Character *onTile = nextCell->getCharacter();
	if(onTile){
		if(onTile->raceType() == "gold"){
			Gold *gold = dynamic_cast<Gold*>(nextCell->transferObj());
			gold->drop(this);
		}else if(onTile->raceType() == "dragonhoard"){
			DragHoard *gold = dynamic_cast<DragHoard*>(onTile);
			if(gold->dragonDied()){
				gold = dynamic_cast<DragHoard*>(nextCell->transferObj());
				gold->pickUp(this);
			}else{
				return; //doesn't do anything it dragon is not dead
			}
		}
	}
	Character::move(dir);
}

void Player::useItem(string &dir){
	Cell *nextTile = currentCell->getNeighbour(dir);
	Potion *pot = dynamic_cast<Potion*>(nextTile->transferObj());
	Player *potPlayer = pot->getUsed(this);
	setCurrentPlayer(potPlayer);
}


