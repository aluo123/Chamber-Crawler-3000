#include "dwarf.h"
#include <string>

Dwarf::Dwarf(Player*player):Enemy(player,100,20,30){}

Dwarf::~Dwarf(){}

void Dwarf::getHit(int dmg){
	if(player->Type()=="vampire"){
		player->getHit(5);
	}else{
		Enemy::getHit(dmg);
	}
}

std::string Dwarf::Type(){
	return "dwarf";
}