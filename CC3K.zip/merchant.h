#ifndef __MERCHANT_H__
#define __MERCHANT_H__

#include "enemy.h"
#include "merchhoard.h"

class Merchant:public Enemy{
	static bool hostile;
public:
	Merchant(Player *player);
	~Merchant();
	
	void dropItem();
	
	void getHit(int dmg);
	
	std::string Type();
};

#endif
