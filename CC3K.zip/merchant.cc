#include "merchant.h"
#include <string>

bool Merchant::hostile = false;

Merchant::Merchant(Player *player):Enemy(player,30,70,5){}
Merchant::~Merchant(){};

void Merchant::dropItem(){
	item = new MerchHoard(player);
	item->drop();
}

void Merchant::getHit(int dmg){
	Character::getHit(dmg);
	hostile = true;
}

std::string Type(){
	return "merchant";
}
