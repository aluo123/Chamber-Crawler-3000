#ifndef __ENEMY_H__
#define __ENEMY_H__

#include "character.h"
#include "item.h"
#include "gold.h"
#include "normalgold.h"
#include "smallgold.h"

class Player;

class Enemy: public Character{	
protected:
	Item *item;
	//instructions for an enemy to dies
	virtual void die(Character *killer);
	
public:
	bool checkRadius();
	Enemy(int hp,int atk,int def);
	virtual ~Enemy();
	//enemies miss 50% of the time 
	virtual void attack(Character *target);
	virtual void dropItem(Character *player);
	std::string characType();
};

#endif

