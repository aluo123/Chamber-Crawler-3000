#include "drow.h"

Drow::Drow():Player(150,25,15){}

Drow::~Drow(){}

std::string Drow::Type(){
	return "drow";
}