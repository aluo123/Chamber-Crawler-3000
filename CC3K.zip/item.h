#ifndef __ITEM_H__
#define __ITEM_H__

#include "player.h"

class Item:public Player{
public:
	Player *player;
	Item():player(NULL){}
	~Item(){}
	
public:
	virtual void drop(Player *player)=0;
	std::string characType(){
		if(player==NULL){
			return "item";
		}else{
			return "player";
		}
	}
};


#endif
