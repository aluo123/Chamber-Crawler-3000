#include "elf.h"
#include <string>

Elf::Elf(Player *player):Enemy(player,40,30,10){}
Elf::~Elf(){}

void Elf::attack(Character *target){
	if(target->Type() == "drow"){
		Enemy::attack(target);
		Enemy::attack(target);
	}else{
		Enemy::attack(target);
	}
}

std::string Elf::Type(){
	return "elf";
}