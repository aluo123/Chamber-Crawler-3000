#ifndef __BAPOT_H__
#define __BAPOT_H__

#include "potion.h"

class BA:public Potion{
public:
	BA(){}
	~BA(){}
	
	std::string raceType(){
		return "bapot";
	}
	
	void getATK(){
		return player->getATK() + 5;
	}
	
	void wearOff(){
		p->setCurrentPlayer(player)
		delete this;		
	}
	
	Player *getUsed(Player *p){
		player = p;
		p->setCurrentPlayer(this);
	}
};

#endif
