#include "troll.h"

Troll::Troll():Player(120,25,15){}

Troll::~Troll(){}

void Troll::attack(Character *target){
	Character::attack(target);
	setHP(getHP()+5);
}

void Troll::move(const std::string &dir){
	Character::move(dir);
	setHP(getHP()+5);
}

std::string Troll::Type(){
	return "troll";
}
