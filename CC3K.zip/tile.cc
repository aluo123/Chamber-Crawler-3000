#include "tile.h"
using namespace std;

Tile::Tile(Floor *f, int row, int col): Cell(f, row, col) {
	c = NULL;
}

Tile::~Tile() {
	delete c;
}

Cell *Tile::move( string dir ) {
	if ( neighbours.count(dir) > 0) {
		if ( neighbours[dir]->acceptChar(c) ) {
			c = NULL;
			notify();
			return neighbours[dir];
		}
	}
	return this;
}

bool Tile::acceptChar( Character *c ) {
	if ( this->c == NULL ) {
		this->c = c;
		return true;
	}
	return false;
}

void Tile::notify() {
	f->notify( row, col, '.');
}

Character *Tile::getCharacter(){
	return c;
}

Character *Tile::transferObj(){
	Character *tmp = c;
	c = NULL;
	return tmp;
}

void Tile::setCharacter( Character * c ){
	this->c = c;
}

