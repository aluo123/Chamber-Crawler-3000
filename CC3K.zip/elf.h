#ifndef __ELF_H__
#define __ELF_H__

#include "enemy.h"
#include <string>

class Elf: public Enemy{
public:
	Elf(Player *player);
	~Elf();
	void attack(Character *target);
	
	std::string Type();
};

#endif
