#ifndef __ORC_H__
#define __ORC_H__

#include "enemy.h"

class Orc: public Enemy{
public:
	Orc(Player *player);
	~Orc();
	
	void attack(Character *target);
};

#endif
