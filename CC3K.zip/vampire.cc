#include "vampire.h"

Vampire::Vampire():Player(50,25,25){}

Vampire::~Vampire(){}

void Vampire::attack(Character *target){
	Character::attack(target);
	setHP(getHP()+5);
}

std::string Vampire::Type(){
	return "vampire";
}