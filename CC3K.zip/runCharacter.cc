#include "character.h"
#include "player.h"
#include "shade.h"

int main(){
	
}