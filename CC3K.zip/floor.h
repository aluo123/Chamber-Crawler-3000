#ifndef __FLOOR_H__ 
#define __FLOOR_H__
#include <map>
#include <string>

class Cell;
class Game;

typedef std::map<std::pair<int, int>, Cell*> chamber;

class Floor{
	Game *g;
	chamber theChambers[5];
	int gridWidth, gridLength;
	Cell* theGrid[25][79];
	void placeChamber( int r, int c );
	void createCell( int r, int c, char ch );
	void initCharacters( int r, int c, char ch );
	void addNeighbours( int row, int col );
	void makeEnemies();
	void makeItems();
	
   public:
	Floor( Game * g );
	~Floor();
	void init();
	void notify();
	void notify( int r, int c, char ch ) const;
	void notify( std::string action ) const ;
	void notify( std::string stat, int newStat ) const;
	
};

#endif
