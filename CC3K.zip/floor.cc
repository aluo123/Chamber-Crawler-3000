#include "floor.h"
#include "wall.h"
#include "cell.h"
#include "tile.h"
#include "game.h"
#include "passage.h"
#include "textdisplay.h"
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

void Floor::placeChamber( int r, int c ) {
	if ( r >= 3 && r <= 6 && c >= 3 && c <= 28 ) {
		theChambers[0][pair<int, int>(r,c)] = theGrid[r][c];
	}
	else if ( r >= 15 && r <= 22 && c >= 4 && c <= 24 ) {
		theChambers[1][pair<int, int>(r,c)] = theGrid[r][c];
	}
	else if ( (( r==3 || r == 4) && c >= 39 && c <= 61) ||
			(r == 5 && c >= 39 && c <= 69) ||
			(r == 6 && c >= 39 && c <= 72) ||
			(r >= 7 && r <= 12 && c >= 61 && c <= 75 )) {
		theChambers[2][pair<int,int>(r,c)] = theGrid[r][c];
	}
	else if ( r >= 10 && r <= 12 && c >= 38 && c <= 49 ) {
		theChambers[3][pair<int, int>(r,c)] = theGrid[r][c];
	}
	else if ( (r >= 16 && r <= 18 && c >= 65 && c <= 75 ) || 
			( r >= 19 && r <= 21 && c >= 37 && c <= 75 )) {
		theChambers[4][pair<int,int>(r,c)] = theGrid[r][c];		
	}
}

void Floor::createCell(int r, int c, char ch) {
	if ( ch == '|' ) {
		theGrid[r][c] = new Wall(true, this, r, c);
	}
	else if ( ch == '-' ) {
		theGrid[r][c] = new Wall(false, this, r, c);
	}
	else if ( ch == '.' ) {
		theGrid[r][c] = new Tile(this,r,c);
	}
	else if ( ch == '+' ) {
		theGrid[r][c] = new Passage(true, this, r, c);
	}
	else if ( ch == '#' ) {
		theGrid[r][c] = new Passage(false, this, r, c);
	}
}

void Floor::initCharacters( int r, int c, char ch ) {
	
}

void Floor::addNeighbours( int row, int col) {
	if ( theGrid[row][col] == NULL ) return;
	if ( row > 0 && theGrid[row-1][col] != NULL ) {
		theGrid[row][col]->addNeighbour("no", theGrid[row-1][col]);
		if ( col > 0 && theGrid[row-1][col-1] != NULL ) {
			theGrid[row][col]->addNeighbour("ne", theGrid[row-1][col-1]);
		}
	}
	if ( col > 0 && theGrid[row][col-1] != NULL ) {
		theGrid[row][col]->addNeighbour("ea", theGrid[row][col-1]);
		if ( row < 24 && theGrid[row+1][col-1] != NULL ) {
			theGrid[row][col]->addNeighbour("se", theGrid[row+1][col-1]);
		}
	}
	if ( row < 24 && theGrid[row+1][col] != NULL ) {
		theGrid[row][col]->addNeighbour("s", theGrid[row+1][col]);
		if( col < 78 && theGrid[row+1][col+1] != NULL ) {
			theGrid[row][col]->addNeighbour("sw", theGrid[row+1][col+1]);
		}
	}
	if ( col < 78 && theGrid[row][col+1] != NULL ) {
		theGrid[row][col]->addNeighbour("we", theGrid[row][col+1]);
		if( row > 0 && theGrid[row-1][col+1] != NULL ) {
			theGrid[row][col]->addNeighbour("nw", theGrid[row-1][col+1]);
		}
	}
}

Floor::Floor( Game * g ): g(g), gridWidth(25), gridLength(79) {
	#ifdef DEBUG
	cout << "Entering floor creation" << endl;
	#endif
	ifstream fs("basefloor.txt");
	string temp;
	for ( int i = 0; i < gridWidth; i++ ) {
		getline(fs, temp);
		istringstream ss(temp);
		for ( int j = 0; j < gridLength; j++ ) {
			char cell;
			ss >> noskipws >> cell;
			createCell(i,j, cell);
		}
	}
	for ( int i = 0; i < gridWidth; i++ ) {
		for( int j = 0; j < gridLength; j++ ) {
			addNeighbours(i,j);
			placeChamber(i,j);
		}
	}
}

Floor::~Floor() {
	for ( int i = 0; i < gridWidth; i++ ) {
		for ( int j = 0; j < gridLength; j++ ) {
			delete theGrid[i][j];
		}
	}
}

void Floor::init() {
	
}
/*
void Floor::init( int r, int c, Character *ch ) {
	
}
*/
void Floor::makeEnemies(){
	
}

void Floor::makeItems(){
	
}

void Floor::notify() {
	cout << "Entering Notify" << endl;
	for ( int i = 0; i < gridWidth; i++ ) {
		for ( int j = 0; j < gridLength; j++ ) {
			if ( theGrid[i][j] != NULL ) {
				theGrid[i][j]->notify();
			}
		}
	}
}

void Floor::notify( int r, int c, char ch ) const {
	g->notify(r,c,ch);
}

void Floor::notify( string action ) const {
	g->notify(action);
}

void Floor::notify( string stat, int newStat ) const {
	g->notify(stat,newStat);
}
