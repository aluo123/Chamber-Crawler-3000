#ifndef __RHPOT_H__
#define __RHPOT_H__
#include "potion.h"

class RH:public Potion{
public:
	RH(){}
	~RH(){}
	
	std::string raceType(){
		return "rhpot";
	}
	
	//hp pots don't wear off
	void wearOff(){return}
	
	Player *getUsed(Player *p){
		if(p->getHP()+10 > p->maxHP){
			p->setHP(p->maxHP)
		}else{
			p->setHP(p->getHP()+10)
		}
		delete this;
	}
};

#endif
