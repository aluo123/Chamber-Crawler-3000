#ifndef __VAMPIRE_H__
#define __VAMPIRE_H__

#include "player.h"

class Vampire:public Player{
public:
	Vampire();
	~Vampire();
	std::string Type();
	void attack(Character *target);

};

#endif
