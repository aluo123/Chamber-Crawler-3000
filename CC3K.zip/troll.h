#ifndef __TROLL_H__
#define __TROLL_H__

#include "player.h"

class Troll:public Player{
public:
	Troll();
	~Troll();
	std::string Type();
	void attack(Character *target);
	void move(const std::string &dir);
};

#endif
