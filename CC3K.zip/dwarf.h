#ifndef __DWARF_H__
#define __DWARF_H__

#include "enemy.h"
#include <string>

class Dwarf:public Enemy{
public:
	Dwarf(Player *player);

	~Dwarf();
	
	void getHit(int dmg);
	std::string Type();

};

#endif
